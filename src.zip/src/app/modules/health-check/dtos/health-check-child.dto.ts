export class HealthCheckChildDto {}
