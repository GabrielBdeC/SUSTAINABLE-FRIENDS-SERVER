export class HealthCheckSpecDto {}
