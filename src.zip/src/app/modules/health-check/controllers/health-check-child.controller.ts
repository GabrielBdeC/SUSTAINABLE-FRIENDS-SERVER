import { Controller } from '@nestjs/common';

@Controller('health-check-child')
export class HealthCheckChildController {}
