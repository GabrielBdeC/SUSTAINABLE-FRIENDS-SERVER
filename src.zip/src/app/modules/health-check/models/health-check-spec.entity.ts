export class HealthCheckSpecEntity {}
