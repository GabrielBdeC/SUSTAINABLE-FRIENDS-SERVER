export class HealthCheckChildEntity {}
