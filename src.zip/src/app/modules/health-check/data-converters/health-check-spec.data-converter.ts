export class HealthCheckSpecDataConverter {}
