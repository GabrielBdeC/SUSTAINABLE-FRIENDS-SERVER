import { HealthCheckChildDataConverter } from './health-check-child.data-converter';

describe('HealthCheckChildDataConverter', () => {
  it('should be defined', () => {
    expect(new HealthCheckChildDataConverter()).toBeDefined();
  });
});
