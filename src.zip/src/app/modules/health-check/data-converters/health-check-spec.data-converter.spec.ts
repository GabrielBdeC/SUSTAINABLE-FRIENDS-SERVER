import { HealthCheckSpecDataConverter } from './health-check-spec.data-converter';

describe('HealthCheckSpecDataConverter', () => {
  it('should be defined', () => {
    expect(new HealthCheckSpecDataConverter()).toBeDefined();
  });
});
