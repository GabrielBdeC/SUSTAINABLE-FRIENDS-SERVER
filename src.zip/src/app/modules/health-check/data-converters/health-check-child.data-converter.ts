export class HealthCheckChildDataConverter {}
