import { HealthCheckDataConverter } from './health-check.data-converter';

describe('HealthCheckDataConverter', () => {
  it('should be defined', () => {
    expect(new HealthCheckDataConverter()).toBeDefined();
  });
});
